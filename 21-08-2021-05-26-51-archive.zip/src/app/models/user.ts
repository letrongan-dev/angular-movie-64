export interface IUser {
  taiKhoan: string;
  matKhau: string;
  hoTen: string;
  email: string;
  soDt: string;
  maNhom: string;
}

export type LoginUser = {
  taiKhoan: string;
  matKhau: string;
};
